function cell_labels = merge_clusters_by_criteria_snr_mean_ratio(selected_data_gene_cluster_mean, cell_labels, selected_gene_labels, snr_merge_threshold, fold_change_merge_threshold, diff_change_merge_threshold)
% selected_data_gene_cluster_mean:  pathway*cell detection matrix
% cell_labels:                      clustering results from iterative cooc

    diff_threshold = max(max(grpstats(selected_data_gene_cluster_mean', cell_labels)'))/10;

    cell_labels_backup = cell_labels;
    
    % merging strategy 0-1 means a modified version of original merging design: use merging criteria to make edges to build a graph to connect cell clusters, report disconnected components as detected clusters. MST + one cut if no disconnected componets 
    cell_labels = cell_labels_backup;
    adj = ones(max(cell_labels),max(cell_labels));
    for i=1:max(cell_labels)
        for j=i+1:max(cell_labels)                
            for k=1:size(selected_data_gene_cluster_mean,1)
                snr1 = abs(get_correlations(selected_data_gene_cluster_mean(k,ismember(cell_labels,[i,j])), cell_labels(ismember(cell_labels,[i,j])), 'snr'))';
                fold_change = exp(abs(log((mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,i)),2) + (1e-10))./ (mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,j)),2) + (1e-10)))));
                mean_diff = abs(mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,i)),2) - mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,j)),2) );
                if ~((snr1<snr_merge_threshold) | ((fold_change<fold_change_merge_threshold | mean_diff<diff_threshold | mean_diff*sum(selected_gene_labels==k)<5) & mean_diff<diff_change_merge_threshold))
                    adj(i,j)=0;
                    adj(j,i)=0;
                end
            end
        end
    end
    [~,~,~,components] = extract_connected_component(adj);
    % fprintf('merging graph has %d components\n', size(components,2))
    if size(components,2)~=1 && size(selected_data_gene_cluster_mean,1)>=2
        new_cell_labels = cell_labels;
        for i=1:size(components,2)
            new_cell_labels(ismember(cell_labels, find(components(:,i))))=i;
        end
        cell_labels = new_cell_labels;
    else
        % [adj,adj2, cost_value] = mst_from_dist_matrix(squareform(tmp(:,3)));
        [adj,adj2, cost_value] = mst_from_dist_matrix(squareform(pdist(grpstats(selected_data_gene_cluster_mean',cell_labels))));
        [i,j] = find(adj==1);
        edges = unique(sort([i,j],2),'rows');
        scores = zeros(size(edges,1),1);
        for i=1:size(edges,1)
            adj_tmp = adj;
            adj_tmp(edges(i,1),edges(i,2))=0;
            adj_tmp(edges(i,2),edges(i,1))=0;
            [~, ~, ~,components] = extract_connected_component(adj_tmp);
            component_1 = find(components(:,1));
            component_2 = find(components(:,2));
            scores(i) = max(abs(get_correlations(selected_data_gene_cluster_mean, ismember(cell_labels,component_2), 'snr'))');
            scores_snr(i) = max(abs(get_correlations(selected_data_gene_cluster_mean, ismember(cell_labels,component_2), 'snr'))');
            scores_fold(i) = max(exp(abs(log((mean(selected_data_gene_cluster_mean(:,ismember(cell_labels,component_1)),2) + (1e-10))./ (mean(selected_data_gene_cluster_mean(:,ismember(cell_labels,component_2)),2) + (1e-10))))));
            [scores_diff(i), ttt] = max(abs(mean(selected_data_gene_cluster_mean(:,ismember(cell_labels,component_1)),2) - mean(selected_data_gene_cluster_mean(:,ismember(cell_labels,component_2)),2) ));
            score_diff_pathway_size(i) = sum(selected_gene_labels==ttt);
        end
        % [max_score,i] = max(scores);
        ind = find(scores_snr>snr_merge_threshold & ((scores_fold>fold_change_merge_threshold & scores_diff>diff_threshold & scores_diff.*score_diff_pathway_size>=5) | scores_diff>diff_change_merge_threshold));
        if isempty(ind) % max_score<snr_merge_threshold
            cell_labels = cell_labels*0 + 1;
        else
            [~,tt] = min(scores_snr(ind));
            i = ind(tt);
            adj_tmp = adj;
            adj_tmp(edges(i,1),edges(i,2))=0;
            adj_tmp(edges(i,2),edges(i,1))=0;
            [~, ~, ~,components] = extract_connected_component(adj_tmp);
            new_cell_labels = cell_labels;
            for i=1:size(components,2)
                new_cell_labels(ismember(cell_labels, find(components(:,i))))=i;
            end
            cell_labels = new_cell_labels;
        end
    end
    cell_labels_0_1 = cell_labels;
    
    % merging strategy 0-2 means new design of iterative merging: use merging criteria to make edges to build a graph to connect cell clusters, report disconnected components as detected clusters. If no disconnected components, merge the two clusters closest to each other in the pathway activity space, re-do the graph and disconnected components analysis. If still no disconnected components, do this again, until there are disconnected components, or all clusters merged 
    cell_labels = cell_labels_backup;
    while 1
        adj = ones(max(cell_labels),max(cell_labels));
        for i=1:max(cell_labels)
            for j=i+1:max(cell_labels)                
                for k=1:size(selected_data_gene_cluster_mean,1)
                    snr1 = abs(get_correlations(selected_data_gene_cluster_mean(k,ismember(cell_labels,[i,j])), cell_labels(ismember(cell_labels,[i,j])), 'snr'))';
                    fold_change = exp(abs(log((mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,i)),2) + (1e-10))./ (mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,j)),2) + (1e-10)))));
                    mean_diff = abs(mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,i)),2) - mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,j)),2) );
                    if ~((snr1<snr_merge_threshold) | ((fold_change<fold_change_merge_threshold | mean_diff<diff_threshold | mean_diff*sum(selected_gene_labels==k)<5) & mean_diff<diff_change_merge_threshold))
                        adj(i,j)=0;
                        adj(j,i)=0;
                    end
                end
            end
        end
        [~,~,~,components] = extract_connected_component(adj);
        if (size(components,2)~=1 && size(selected_data_gene_cluster_mean,1)>=2) || (size(components,2)==2 && size(selected_data_gene_cluster_mean,1)==1)
            new_cell_labels = cell_labels;
            for i=1:size(components,2)
                new_cell_labels(ismember(cell_labels, find(components(:,i))))=i;
            end
            cell_labels = new_cell_labels;
            break;
        end
        pairwise_dist = squareform(pdist(grpstats(selected_data_gene_cluster_mean',cell_labels)));
        pairwise_dist(adj==0) = Inf;
        pairwise_dist = pairwise_dist + diag(repmat(Inf,1,size(pairwise_dist,1)));
        [i,j] = find(pairwise_dist==min(pairwise_dist(:))); i=i(1); j=j(1);
        cell_labels(cell_labels==max(i,j)) = min(i,j);
        cell_labels = standardize_idx(cell_labels);
        if max(cell_labels)==1
            break;
        end
    end
    cell_labels_0_2 = cell_labels;
    
    % merging strategy 0-3 means new design of iterative merging: use merging criteria to make edges to build a graph to connect cell clusters, as long as there are edges, start merging the pair that are closest to each other in the pathway activity space, redo the graph, merge again, redo graph and repeat until the graph has no edge. Report the final clusters as detected clusters.
    cell_labels = cell_labels_backup;
    while 1
        tmp = [];
        adj = ones(max(cell_labels),max(cell_labels));
        for i=1:max(cell_labels)
            for j=i+1:max(cell_labels)                
                for k=1:size(selected_data_gene_cluster_mean,1)
                    snr1 = abs(get_correlations(selected_data_gene_cluster_mean(k,ismember(cell_labels,[i,j])), cell_labels(ismember(cell_labels,[i,j])), 'snr'))';
                    fold_change = exp(abs(log((mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,i)),2) + (1e-10))./ (mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,j)),2) + (1e-10)))));
                    mean_diff = abs(mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,i)),2) - mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,j)),2) );
                    if ~((snr1<snr_merge_threshold) | ((fold_change<fold_change_merge_threshold | mean_diff<diff_threshold | mean_diff*sum(selected_gene_labels==k)<5) & mean_diff<diff_change_merge_threshold))
                        adj(i,j)=0;
                        adj(j,i)=0;
                    end
                end
            end
        end
        if sum(sum(triu(adj,1)))==0
            break;
        end
        pairwise_dist = squareform(pdist(grpstats(selected_data_gene_cluster_mean',cell_labels)));
        pairwise_dist(adj==0) = Inf;
        pairwise_dist = pairwise_dist + diag(repmat(Inf,1,size(pairwise_dist,1)));
        [i,j] = find(pairwise_dist==min(pairwise_dist(:))); i=i(1); j=j(1);
        cell_labels(cell_labels==max(i,j)) = min(i,j);
        cell_labels = standardize_idx(cell_labels);
        if max(cell_labels)==1
            break;
        end
    end  
    cell_labels_0_3 = cell_labels;
    
    % use the one with the largest number of clusters
    cell_labels = cell_labels_0_1;
    if max(cell_labels_0_2)>=max(cell_labels)
        cell_labels = cell_labels_0_2;
    end
    if max(cell_labels_0_3)>=max(cell_labels)
        cell_labels = cell_labels_0_3;
    end    