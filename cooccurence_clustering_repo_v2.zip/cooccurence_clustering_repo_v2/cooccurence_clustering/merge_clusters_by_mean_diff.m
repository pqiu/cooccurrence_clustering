function cell_labels = merge_clusters_by_mean_diff(selected_data_gene_cluster_mean, cell_labels, selected_gene_labels)
% selected_data_gene_cluster_mean:  pathway*cell detection matrix
% cell_labels:                      clustering results from iterative cooc
    
    diff_threshold = max(max(grpstats(selected_data_gene_cluster_mean', cell_labels)'))/10;
    
    while 1
        adj = ones(max(cell_labels),max(cell_labels));
        for i=1:max(cell_labels)
            for j=i+1:max(cell_labels)                
                for k=1:size(selected_data_gene_cluster_mean,1)
                    mean_diff = abs(mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,i)),2) - mean(selected_data_gene_cluster_mean(k,ismember(cell_labels,j)),2) );
                    if ~(mean_diff<diff_threshold | mean_diff*sum(selected_gene_labels==k)<5)
                        adj(i,j)=0;
                        adj(j,i)=0;
                    end
                end
            end
        end
        if sum(sum(triu(adj,1)))==0
            break;
        end
        pairwise_dist = squareform(pdist(grpstats(selected_data_gene_cluster_mean',cell_labels)));
        pairwise_dist(adj==0) = Inf;
        pairwise_dist = pairwise_dist + diag(repmat(Inf,1,size(pairwise_dist,1)));
        [i,j] = find(pairwise_dist==min(pairwise_dist(:))); i=i(1); j=j(1);
        cell_labels(cell_labels==max(i,j)) = min(i,j);
        cell_labels = standardize_idx(cell_labels);
        if max(cell_labels)==1
            break;
        end
    end
    
    