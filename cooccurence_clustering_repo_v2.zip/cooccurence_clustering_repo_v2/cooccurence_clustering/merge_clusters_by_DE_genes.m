function cell_labels = merge_clusters_by_DE_genes(normalized_data, cell_labels, merging_mode, required_num_of_DE_genes, pvalue_threshold, fdr_threshold)
% normalized_data:  after the following operations counts -> library size normalization -> log (1+x)
% cell_labels:      clustering results from iterative cooc
% merging_mode:     1 or 2 (pvalue or fdr)
% required_num_of_DE_genes
% pvalue_threshold
% fdr_threshold

    
    fprintf('Computing pairwise DE for %d clusters ... %3d', max(cell_labels), 0);
    adj = ones(max(cell_labels),max(cell_labels));
    for i=1:max(cell_labels)
        fprintf('\b\b\b%3d', i);
        for j=i+1:max(cell_labels)              
            [H,P] = ttest2(full(normalized_data(:,cell_labels==i))',full(normalized_data(:,cell_labels==j))');
            if merging_mode==1
                num_significant_genes = sum(P<pvalue_threshold/size(normalized_data,1));
            elseif merging_mode==2
                num_significant_genes = sum(mafdr(P)<fdr_threshold);
            end
            if num_significant_genes>=required_num_of_DE_genes
                adj(i,j)=0;
                adj(j,i)=0;
            else
                adj(i,j) = num_significant_genes;
                adj(j,i) = num_significant_genes;
            end
        end
    end
    fprintf('\b\b\bDone\n');
    
    fprintf('Iterative merge with number of clusters being: %3d', max(cell_labels));
    while 1
        if sum(sum(triu(adj,1)))==0
            break;
        end
        pairwise_dist = adj; 
        pairwise_dist(adj==0) = Inf;
        pairwise_dist = pairwise_dist + diag(repmat(Inf,1,size(pairwise_dist,1)));
        [ind_i,ind_j] = find(pairwise_dist==min(pairwise_dist(:))); ind_i=ind_i(1); ind_j=ind_j(1);
        cell_labels(cell_labels==max(ind_i,ind_j)) = min(ind_i,ind_j);
        cell_labels = standardize_idx(cell_labels);
        if max(cell_labels)==1
            break;
        end
        
        % update adj for the next iteration
        adj(max(ind_i,ind_j),:)=[];
        adj(:,max(ind_i,ind_j))=[];
        for i=1:max(cell_labels)
            [H,P] = ttest2(full(normalized_data(:,cell_labels==i))',full(normalized_data(:,cell_labels==min(ind_i,ind_j)))');
            if merging_mode==1
                num_significant_genes = sum(P<pvalue_threshold/size(normalized_data,1));
            elseif merging_mode==2
                num_significant_genes = sum(mafdr(P)<fdr_threshold);
            end
            if num_significant_genes>=required_num_of_DE_genes
                adj(i,min(ind_i,ind_j))=0;
                adj(min(ind_i,ind_j),i)=0;
            else
                adj(i,min(ind_i,ind_j)) = num_significant_genes;
                adj(min(ind_i,ind_j),i) = num_significant_genes;
            end
        end
        fprintf('\b\b\b%3d', max(cell_labels));
    end  
    fprintf('\n');
