%% addpath to all tools
addpath(genpath('../cooccurence_clustering/'))


%% initiate one instance of the "cooccurrence_clustering_analysis" class
cooc = cooccurrence_clustering_analysis;


%% read data prepawed in matlab file
cooc = cooc.ReadMatlab('Burns.mat');


%% filter the data by removing genes and cells (same as Seurat tutorial on this data)
cooc.initial_filtering_min_num_cells = 10;
cooc.initial_filtering_min_num_genes = 0;
cooc.initial_filtering_max_num_genes = Inf;
cooc.initial_filtering_max_percent_mito = 1;
cooc = cooc.initial_filtering_of_data(1);



%% binarize data
cooc.binarization_threshold = 0;
cooc.binary_data = full(double(cooc.data>cooc.binarization_threshold));



%% cooccurrence clustering
cooc.cooccurrence_min_expressed_cells = 10;             % genes will only be considered if detected in >= minimum number of cells, and undetected in >= minimum number of cells
cooc.cooccurrence_min_pathway_size = 20;                % only considered gene clusters of size >= this threshold
cooc.cooccurrence_min_population_size = 10;             % only considered gene clusters of size >= this threshold
cooc.cooccurrence_snr_merge_threshold = 1.5;            % if merging_mode==0, threshold for merging Louvain communities, based on snr of average detection of each gene cluster
cooc.cooccurrence_mean_diff_merge_threshold = 0.3;      % if merging_mode==0, threshold for merging Louvain communities
cooc.cooccurrence_mean_ratio_merge_threshold = 2;       % if merging_mode==0, threshold for merging Louvain communities
cooc.required_num_of_DE_genes = 10;                     % if merging_mode==1, threshold for required number of differentially expressed genes for merging Louvain communities 
cooc.pvalue_threshold = 0.01;                           % if merging_mode==1, need to specify required_num_of_DE_genes for the merging criterion, threshold based on pvalue

cooc.merging_mode = 0;                                  
% 0 means use binary info for merging (same concept but slightly updated implementation compared to the details presented in Qiu, "Embracing the dropouts in single-cell RNA-seq analysis", Nature Communications, 2020. )
% 1 means use quantitative data and number of differentially expressed genes as merging criterion (this implementation tends to generate more clusters) 


cooc = cooc.iterative_cooccurance_clustering;



%% re-order pathways for better visualization

pathway_in_cell_detection_rate = cooc.pathway_in_cell_detection_rate;
scores = zeros(size(pathway_in_cell_detection_rate,1),max(cooc.cell_labels));
for k=1:max(cooc.cell_labels)
    for l=k+1:max(cooc.cell_labels)
        tmp = get_correlations(pathway_in_cell_detection_rate(:,ismember(cooc.cell_labels,[k,l])),cooc.cell_labels(ismember(cooc.cell_labels,[k,l])),'snr');
        scores(:,k) = scores(:,k) - tmp;
        scores(:,l) = scores(:,l) + tmp;
    end
end
[max_score,signature_for_which_celltype] = max(scores,[],2);
pathway_order = [];
for k=1:max(cooc.cell_labels)
    tmp_pathway = find(signature_for_which_celltype==k);
    [~,I] = sort(max_score(tmp_pathway),'descend');
    pathway_order = [pathway_order;tmp_pathway(I)];
end    
cooc.pathway_in_cell_detection_rate = cooc.pathway_in_cell_detection_rate(pathway_order,:);
cooc.gene_pathway_indicator = cooc.gene_pathway_indicator(:,pathway_order);
                    


%% Visualize the percentages of detecion for pathways in individual cells

[~,I] = sort(cooc.cell_labels);
h = figure(30); set(h, 'position', [100 100 1200 600]);
subplot(6,1,1:4); imagesc(cooc.pathway_in_cell_detection_rate(:, I)./max(cooc.pathway_in_cell_detection_rate(:, I),[],2)); ylabel('pathways (gene clusters)'); xlabel('cells'); title('Percentage of detection')
h = subplot(4,1,4); imagesc(cooc.cell_labels(I)); h.YTick=[];
for k=1:max(cooc.cell_labels)
    text(mean(find(cooc.cell_labels(I)==k)), 1, num2str(unique(cooc.cell_labels_history(cooc.cell_labels==k,end))));
end
title('co-occurrence cell clusters'); xlabel('cells')


h = figure(40); set(h, 'position', [100 100 1200 600]);
subplot(6,1,1:4); imagesc(cooc.pathway_in_cell_detection_rate(:, I)./max(cooc.pathway_in_cell_detection_rate(:, I),[],2)); ylabel('pathways (gene clusters)'); xlabel('cells'); title('Percentage of detection')
h = subplot(4,1,4); imagesc(cooc.cell_labels(I)); h.YTick=[];
for k=1:max(cooc.cell_labels)
    text(mean(find(cooc.cell_labels(I)==k)), 1, num2str(k));
end
title('co-occurrence cell clusters (renamed)'); xlabel('cells')



%%

h = figure(5); set(h, 'units','normalized','outerposition',[0 0 1 1])
for i=1:size(cooc.pathway_in_cell_detection_rate,1)
    tmp = cell(0);
    for k=1:max(cooc.cell_labels)
        tmp{k} = cooc.pathway_in_cell_detection_rate(i,cooc.cell_labels==k);
    end
    subplot(5, ceil(size(cooc.pathway_in_cell_detection_rate,1)/5),i); violin(tmp,'mc',[],'medc',[]);
    title(num2str(i,'Pathway - %d'))
    xlabel('cell clusters');
    ylabel('% detection');
    drawnow
end



%% export results to files

% pathway_names = strcat('pathway-',regexp(num2str(1:size(cooc.gene_pathway_indicator,2),'%05d,'),',','split')'); pathway_names(end)=[];
% write_to_txt_v2([mfilename,'_result_gene_pathway_indicator.csv'],[{' '}, pathway_names'], cooc.gene_names, cooc.gene_pathway_indicator,',');
% write_to_txt_v2([mfilename,'_result_pathway_in_cell_detection_rate.csv'],[{' '}, cooc.cell_names], pathway_names, cooc.pathway_in_cell_detection_rate,',');
% write_to_txt_v2([mfilename,'_result_cell_clusters.csv'],[{' '}, cooc.cell_names], {'cluster idx'}, cooc.cell_labels,',');


%% compare with seurat

load Burns_metadata.mat class_labels

label_1 = zeros(size(class_labels));
label_1(isInList(class_labels,': TEC'))=1;
label_1(isInList(class_labels,' SC'))=2;
label_1(isInList(class_labels,': HC'))=3;
label_1(isInList(class_labels,': NSC'))=4;
seurat_cell_labels = label_1;
seurat_cell_type_names = {'TEC','SC','HC','NSC'}; 


C = compare_two_idx_confusion(seurat_cell_labels(seurat_cell_labels~=0),cooc.cell_labels(seurat_cell_labels~=0));
normalized_C = C./sum(C);
[~,I] = sort(normalized_C,'descend');
[~,I] = sort(I(1,:));


%%
h = figure(1);
h.Position=[201 300 1200 500]
h = subplot(6,1,1:5);
imagesc(normalized_C(:,I));
set(h, 'YTick', 1:length(unique(seurat_cell_labels)), 'YTickLabel', seurat_cell_type_names, 'XTick', 1:size(C,2), 'XTickLabel', I);
% sss = unique([cooc.cell_labels', cooc.cell_labels_history(:,end)],'row'); h.Children.XTickLabel = sss(I,2);

for i=1:size(normalized_C(:,I),1)
    for j=1:size(normalized_C(:,I),2)
        text(j-0.2,i-0.2,num2str(normalized_C(i,I(j))*100,'%1.1f%%'))
        text(j-0.2,i+0.2,num2str(C(i,I(j)),'(%d)'))
    end
end


xlabel('co-occurrence clusters','fontsize',15)
ylabel('seurat clusters','fontsize',15)
colorbar



h = subplot(10,1,10); imagesc(I);
set(h, 'YTick', [], 'XTick',[])
for k=1:length(I)
    text(k, 1, num2str(unique(cooc.cell_labels_history(cooc.cell_labels==I(k),end))));
end
h = colorbar; h.Visible='off';


