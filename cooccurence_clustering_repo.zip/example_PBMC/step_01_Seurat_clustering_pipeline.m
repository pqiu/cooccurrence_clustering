%% addpath to all tools
addpath(genpath('../tools/'))


%% initiate one instance of the "cooccurrence_clustering_analysis" class
pbmc = cooccurrence_clustering_analysis;


%% read data downloaded from 10X
pbmc = pbmc.Read10X('Downloads/filtered_gene_bc_matrices/hg19/');


%% filter the data by removing genes and cells
pbmc.initial_filtering_min_num_cells = 3;
pbmc.initial_filtering_min_num_genes = 200;
pbmc.initial_filtering_max_num_genes = 2500;
pbmc.initial_filtering_max_percent_mito = 0.05;
pbmc = pbmc.initial_filtering_of_data(1);


%% scale data by cells nUMI
pbmc.nUMI_scaling_factor = 10000; 
pbmc = scale_cells_by_nUMI(pbmc);


%% log normalize data
pbmc.normalization_method = 'log1p';
pbmc = pbmc.normalize_data;


%% select HVG (code designed to work with log1p normalized data
pbmc.expmean_threshold_low = 0.0125;                % expmean threshold for selecting HVG
pbmc.expmean_threshold_high = 3;                    % expmean threshold for selecting HVG
pbmc.dispersion_threshold_low = 0.5;                % dispersion threshold for selecting HVG
pbmc = pbmc.select_high_variance_genes(1);


%% regress out unwanted variations
nUMI = sum(pbmc.raw_data(:,pbmc.cells_to_keep),1);
mito_genes = pbmc.raw_gene_names(isInListFront(pbmc.raw_gene_names,'MT-'));
percent_mito = full(sum(pbmc.raw_data(ismember(pbmc.raw_gene_names, mito_genes),pbmc.cells_to_keep),1)./nUMI);
pbmc = pbmc.add_metadata(nUMI,'nUMI');
pbmc = pbmc.add_metadata(percent_mito,'percent_mito');
pbmc = pbmc.regress_out_unwanted_variation;


%% PCA
pbmc.num_PC = 20;
pbmc = pbmc.PCA(pbmc.residue_data, pbmc.high_variance_genes);

figure(4); plot(pbmc.PCA_cell_embeddings(:,1),pbmc.PCA_cell_embeddings(:,2),'.')

figure(5); 
h=subplot(1,2,1);
PC_ind = 1;
[Y] = sort(abs(pbmc.PCA_gene_loadings(:,PC_ind)),'descend'); threshold_tmp = Y(30); 
[Y,I] = sort(pbmc.PCA_gene_loadings(:,PC_ind),'descend'); 
plot(pbmc.PCA_gene_loadings(I(abs(Y)>=threshold_tmp),PC_ind),1:30,'o')
h.YTick=1:30; h.YTickLabel=pbmc.high_variance_genes(I(abs(Y)>=threshold_tmp));

h=subplot(1,2,2);
PC_ind = 2;
[Y] = sort(abs(pbmc.PCA_gene_loadings(:,PC_ind)),'descend'); threshold_tmp = Y(30); 
[Y,I] = sort(pbmc.PCA_gene_loadings(:,PC_ind),'descend'); 
plot(pbmc.PCA_gene_loadings(I(abs(Y)>=threshold_tmp),PC_ind),1:30,'o')
h.YTick=1:30; h.YTickLabel=pbmc.high_variance_genes(I(abs(Y)>=threshold_tmp));



%% PCA number of significant PC's
figure(6)
[num_significant_PCs, max_random_variance] = pbmc.PCA_significant_PC_by_permutation(10);
num_significant_PCs
plot(pbmc.PCA_variances,'o'); line(xlim,max_random_variance*[1 1])
title(num2str(num_significant_PCs, 'Significant PCs = %d')); xlabel('PC'); ylabel('standard deviation')
figure(7)
[num_significant_PCs,pvalues] = pbmc.PCA_significant_PC_by_jackstraw(100,0.01,1);
num_significant_PCs




%% Seurat clustering
pbmc = pbmc.seurat_clustering(pbmc.PCA_cell_embeddings(:,1:20), 30, 1/15, 0.6);
tic
fprintf('Computing tSNE visualization ...')
tSNE_map = tsne(pbmc.PCA_cell_embeddings(:,1:10));
toc
figure(9)
scatter(tSNE_map(:,1),tSNE_map(:,2),20,pbmc.cell_labels_seurat,'fill'); title('tSNE')


%% 
close all
save step_01_seurat_result

