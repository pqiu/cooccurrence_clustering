close all

%% load seurat clusters
table_content = read_xls_v2('Downloads/Seurat_clusters.csv',char(9),1);
tmp = regexp(cell2mat(table_content'),'"','split');
seurat_cell_names = tmp(2:4:end);
seurat_cell_labels = str2double(tmp(4:4:end))+1;

seurat_cell_labels2 = zeros(size(seurat_cell_labels));
seurat_cell_labels2(seurat_cell_labels==3) = 1;
seurat_cell_labels2(seurat_cell_labels==7) = 2;
seurat_cell_labels2(seurat_cell_labels==1) = 3;
seurat_cell_labels2(seurat_cell_labels==4) = 4;
seurat_cell_labels2(seurat_cell_labels==6) = 5;
seurat_cell_labels2(seurat_cell_labels==2) = 6;
seurat_cell_labels2(seurat_cell_labels==5) = 7;
seurat_cell_labels2(seurat_cell_labels==8) = 8;

seurat_cell_labels = seurat_cell_labels2;
seurat_cell_type_names = {'B cells', 'Dendritic Cells', 'CD4 T cells', 'CD8 T cells',  'NK cells', 'CD14+ Monocytes', 'FCGR3A+ Monocytes', 'Megakaryocytes'}; 


%% load my own
load('step_02_cooccurrence_clustering_pipeline_result.mat','pbmc')

C = compare_two_idx_confusion(seurat_cell_labels,pbmc.cell_labels);
normalized_C = C./sum(C);
[~,I] = sort(normalized_C,'descend');
[~,I] = sort(I(1,:));
h = figure(1);
h.Position=[201 300 1200 500]
imagesc(normalized_C(:,I));
h.Children.YTick = 1:length(unique(seurat_cell_labels));
h.Children.YTickLabel = seurat_cell_type_names; 
h.Children.XTick = 1:size(C,2); 
%h.Children.XTickLabel = I; 
sss = unique([pbmc.cell_labels', pbmc.cell_labels_history(:,end)],'row'); h.Children.XTickLabel = sss(I,2);

xlabel('co-occurrence clusters','fontsize',15)
ylabel('seurat clusters','fontsize',15)
colorbar

%%
coocurrence_labels = zeros(size(pbmc.cell_labels)); 
for i=1:length(I)
    coocurrence_labels(pbmc.cell_labels==I(i)) = i; 
end

compare_two_idx_confusion(seurat_cell_labels,coocurrence_labels)

%%

RandIndex(pbmc.cell_labels, seurat_cell_labels)

%%
for i=1:size(normalized_C(:,I),1)
    for j=1:size(normalized_C(:,I),2)
        text(j-0.2,i-0.2,num2str(normalized_C(i,I(j))*100,'%1.1f%%'))
        text(j-0.2,i+0.2,num2str(C(i,I(j)),'(%d)'))
    end
end


%%
load('step_01_seurat_result.mat','pbmc')
high_variance_genes = pbmc.high_variance_genes;

load('step_02_cooccurrence_clustering_pipeline_result.mat','pbmc')
cooc_genes = pbmc.gene_names(sum(pbmc.gene_labels_history~=0,2)~=0);

length(high_variance_genes)
length(cooc_genes)
length(intersect(high_variance_genes, cooc_genes))


% %% Compare the two B cell clusters
% cluster_5_binary_data = pbmc.binary_data(:,pbmc.cell_labels_history(:,end)==5);
% cluster_7_binary_data = pbmc.binary_data(:,pbmc.cell_labels_history(:,end)==7);
% 
% [Y,I] = sort(mean(cluster_5_binary_data,2) - mean(cluster_7_binary_data,2),'descend')
% 

% %% CD14+ Monocytes
% 
% pathhway_to_annotate = pbmc.gene_names(pbmc.gene_labels_history(:,4)==10);
% annotations = MSigDB_annotate_geneset(pathhway_to_annotate, pbmc.gene_names, {'h.all', 'c2.cgp', 'c2.cp', 'c3.tft'})
% 
% pathhway_to_annotate = pbmc.gene_names(pbmc.gene_labels_history(:,4)==11);
% annotations = MSigDB_annotate_geneset(pathhway_to_annotate, pbmc.gene_names, {'h.all', 'c2.cgp', 'c2.cp', 'c3.tft'})
% 

%%
% s = grpstats(pbmc.pathway_in_cell_detection_rate', pbmc.cell_labels')';
% imagesc(s./max(s,[],2))

rng(50)
tSNEmap = tsne(pbmc.pathway_in_cell_detection_rate');

%%
h = figure(10)
h.Position = [769.8000 137.8000 766.4000 740.8000]
subplot(2,4,1:3)
scatter(tSNEmap(:,1),tSNEmap(:,2),30,seurat_cell_labels,'fill')
title('Seurat clusters','fontsize',15)
subplot(2,4,4);
scatter(55*ones(1,length(seurat_cell_type_names)),30-(1:length(seurat_cell_type_names))*10,80,1:length(seurat_cell_type_names),'fill')
for i=1:length(seurat_cell_type_names)
    text(60,30-i*10,seurat_cell_type_names{i})
end
ylim([-90,40]); xlim([50,90]); axis off
subplot(2,4,5:7)
scatter(tSNEmap(:,1),tSNEmap(:,2),30,coocurrence_labels,'fill')
title('co-occurrence clusters','fontsize',15)
subplot(2,4,8);
scatter(55*ones(1,length(sss(I,2))),30-(1:length(sss(I,2)))*10,80,1:length(sss(I,2)),'fill')
for i=1:length(sss(I,2))
    text(60,30-i*10,['cluster ',num2str(sss(I(i),2))])
end
ylim([-90,40]); xlim([50,90]); axis off

% %%
% for i=1:size(pbmc.gene_pathway_indicator,2)
%     i
%     pathhway_to_annotate = pbmc.gene_names(pbmc.gene_pathway_indicator(:,i)==1);
%     annotations = MSigDB_annotate_geneset(pathhway_to_annotate, pbmc.gene_names)
% end
