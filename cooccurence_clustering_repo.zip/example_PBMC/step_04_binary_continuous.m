
%% load my own
load('step_02_cooccurrence_clustering_pipeline_result.mat','pbmc')
% load('step_01_seurat_result.mat','pbmc')

%%
subplot_positions = [1 6 2 7 3 4 5 11 12 13 8 9 10]; %[6 1 2 7 8 3 4 11 12 13 5 9 10]

for i=1:max(max(pbmc.gene_labels_history))
    subplot(3,5,subplot_positions(i));
    tmp_data = full(pbmc.data(sum(pbmc.gene_labels_history==i,2)==1,:));
    freq = mean(tmp_data~=0);

    tmp_data(tmp_data==0)=NaN;
    expr = nanmean(log2(tmp_data));
    scatter(freq,expr,20,coocurrence_labels,'fill')
    
    gene_labels_history_column_ind = find(sum(pbmc.gene_labels_history==i)~=0);
    title(['Pathway ', char('a'+i-min(pbmc.gene_labels_history(pbmc.gene_labels_history(:,gene_labels_history_column_ind)~=0,gene_labels_history_column_ind))), ' in Fig 1(',char(gene_labels_history_column_ind-2+'a'),')'], 'fontsize', 13)
    
    if subplot_positions(i)==6
        ylabel('Averge log expression of non-zero counts','fontsize',15)
    end
    if subplot_positions(i)==13
        xlabel('Pathway activity (detection rate)','fontsize',15)
    end
end



subplot(3,5,14);
scatter(55*ones(1,length(sss(I,2))),30-(1:length(sss(I,2)))*10,80,1:length(sss(I,2)),'fill')
for i=1:length(sss(I,2))
    text(60,30-i*10,['Co-occurrence cluster ',num2str(sss(I(i),2))])
end
ylim([-90,30]); xlim([50,90]); axis off
