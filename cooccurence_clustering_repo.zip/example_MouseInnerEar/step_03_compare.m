close all

%% load previously defined clusters
load Burns_metadata.mat class_labels

label_1 = zeros(size(class_labels));
label_1(isInList(class_labels,': TEC'))=1;
label_1(isInList(class_labels,' SC'))=2;
label_1(isInList(class_labels,': HC'))=3;
label_1(isInList(class_labels,': NSC'))=4;
hierarchical_cluster_names = {'TEC','SC','HC','NSC'}; 



%% load my own
load('step_02_cooccurrence_clustering_pipeline_result.mat','cooc')


C = compare_two_idx_confusion(label_1(label_1~=0),cooc.cell_labels(label_1~=0));
normalized_C = C./sum(C);
[~,I] = sort(normalized_C,'descend');
[~,I] = sort(I(1,:));
h = figure(1);
h.Position=[201 300 1200 500]
imagesc(normalized_C(:,I));

h.Children.YTick = 1:length(unique(label_1(label_1~=0)));
h.Children.YTickLabel = hierarchical_cluster_names; 
h.Children.XTick = 1:size(C,2); 
h.Children.XTickLabel = I; 
sss = unique([cooc.cell_labels', cooc.cell_labels_history(:,end)],'row'); h.Children.XTickLabel = sss(I,2);
xlabel('co-occurrence clusters','fontsize',15)
ylabel('experimenally isolated clusters','fontsize',15)
colorbar
 
%%
coocurrence_labels = zeros(size(cooc.cell_labels)); 
for i=1:length(I)
    coocurrence_labels(cooc.cell_labels==I(i)) = i; 
end
 
compare_two_idx_confusion(label_1(label_1~=0),coocurrence_labels(label_1~=0))

%%

RandIndex(cooc.cell_labels(label_1~=0), label_1(label_1~=0))

%%
for i=1:size(normalized_C(:,I),1)
    for j=1:size(normalized_C(:,I),2)
        text(j-0.2,i-0.2,num2str(normalized_C(i,I(j))*100,'%1.1f%%'))
        text(j-0.2,i+0.2,num2str(C(i,I(j)),'(%d)'))
    end
end

%%
rng(50)
tSNEmap = tsne(cooc.pathway_in_cell_detection_rate');

%%
h = figure(10)
h.Position = [769.8000 137.8000 766.4000 740.8000]
subplot(2,4,1:3)
scatter(tSNEmap(label_1~=0,1),tSNEmap(label_1~=0,2),30,label_1(label_1~=0),'fill')
title('experimenally isolated clusters','fontsize',15)
subplot(2,4,4);
scatter(55*ones(1,length(hierarchical_cluster_names)),30-(1:length(hierarchical_cluster_names))*10,80,1:length(hierarchical_cluster_names),'fill')
for i=1:length(hierarchical_cluster_names)
    text(60,30-i*10,hierarchical_cluster_names{i})
end
ylim([-90,40]); xlim([50,90]); axis off
subplot(2,4,5:7)
scatter(tSNEmap(label_1~=0,1),tSNEmap(label_1~=0,2),30,coocurrence_labels(label_1~=0),'fill')
title('co-occurrence clusters','fontsize',15)
subplot(2,4,8);
scatter(55*ones(1,length(sss(I,2))),30-(1:length(sss(I,2)))*10,80,1:length(sss(I,2)),'fill')
for i=1:length(sss(I,2))
    text(60,30-i*10,['cluster ',num2str(sss(I(i),2))])
end
ylim([-90,40]); xlim([50,90]); axis off
