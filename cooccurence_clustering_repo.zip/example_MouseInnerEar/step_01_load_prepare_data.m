%% load metadata

table_content = importdata('download_data\GSE71982_series_matrix.txt');
rows = regexp(table_content,char(10),'split');

class_labels = regexp(rows{52},char(9),'split'); class_labels(1)=[];
sample_names = regexp(rows{39},char(9),'split'); sample_names(1)=[];
for i=1:length(sample_names) 
    sample_names{i}(sample_names{i}=='"')=[];
end


%% parse raw counts data
table_content = importdata('download_data\GSE71982_RSEM_Counts_Matrix.txt');
rows = regexp(table_content,char(10),'split')';

raw_cell_names = regexp(rows{1},char(9),'split'); raw_cell_names(1)=[];
[~,IA,IB] = intersect(raw_cell_names, sample_names);

sample_names(IA) = sample_names(IB); isequal(sample_names, raw_cell_names)
class_labels(IA) = class_labels(IB);

raw_gene_names = cell(0);
raw_data = zeros(length(rows)-1,length(raw_cell_names));
counter = 1;
for i=2:length(rows)
    tmp = regexp(rows{i},char(9),'split');
    gene_name_tmp = tmp{1}; gene_name_tmp(gene_name_tmp=='"')=[];
    raw_gene_names(counter,1) = {gene_name_tmp};
    raw_data(counter,:) = str2double(tmp(2:end));
    counter = counter + 1;
end

raw_data = sparse(raw_data);

save Burns.mat  raw_data  raw_gene_names  raw_cell_names
save Burns_metadata.mat class_labels
